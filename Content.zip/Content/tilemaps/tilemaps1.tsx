<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tilemaps1" tilewidth="16" tileheight="16" tilecount="90" columns="10">
 <image source="tilemaps.png" width="160" height="144"/>
 <tile id="2" probability="0.01"/>
 <tile id="3" probability="0.01"/>
 <tile id="12" probability="0.01"/>
 <tile id="13" probability="0.01"/>
 <tile id="15">
  <properties>
   <property name="terraintype" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="terraintype" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="20" probability="0.01"/>
 <tile id="21" probability="0.01"/>
 <tile id="22" probability="0.01"/>
 <tile id="23" probability="0.01"/>
 <tile id="33" probability="0.01"/>
 <tile id="41">
  <properties>
   <property name="terraintype" type="int" value="2"/>
  </properties>
 </tile>
 <tile id="43" probability="0.01"/>
 <tile id="48">
  <properties>
   <property name="terraintype" type="int" value="0"/>
  </properties>
 </tile>
</tileset>
